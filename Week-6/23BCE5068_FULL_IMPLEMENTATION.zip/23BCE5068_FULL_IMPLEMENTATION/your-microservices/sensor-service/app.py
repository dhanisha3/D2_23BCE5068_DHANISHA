#!/usr/bin/env python3
"""
Sensor Data Microservice - Handles sensor readings only
"""

from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime, timedelta
import random
import os 

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sensor_data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

CORS(app)
db = SQLAlchemy(app)

# Database Models (from your original app.py)
class SensorReading(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    water_level = db.Column(db.Float, nullable=False)
    flow_rate = db.Column(db.Float, nullable=False)
    soil_moisture = db.Column(db.Float, nullable=False)
    water_temperature = db.Column(db.Float, nullable=False)

# Health check
@app.route('/health')
def health_check():
    return jsonify({'status': 'healthy', 'service': 'sensor-service'})

# Your original sensor routes
@app.route('/api/sensors/current')
def get_current_sensors():
    """Get the latest sensor readings - FROM YOUR ORIGINAL CODE"""
    latest = SensorReading.query.order_by(SensorReading.timestamp.desc()).first()
    if not latest:
        return jsonify({'error': 'No sensor data available'}), 404
    
    return jsonify({
        'timestamp': latest.timestamp.isoformat(),
        'water_level': latest.water_level,
        'flow_rate': latest.flow_rate,
        'soil_moisture': latest.soil_moisture,
        'water_temperature': latest.water_temperature
    })

@app.route('/api/sensors/history')
def get_sensor_history():
    """Get sensor readings for the last 24 hours - FROM YOUR ORIGINAL CODE"""
    since = datetime.utcnow() - timedelta(hours=24)
    readings = SensorReading.query.filter(
        SensorReading.timestamp >= since
    ).order_by(SensorReading.timestamp.desc()).limit(50).all()
    
    data = []
    for reading in reversed(readings):
        data.append({
            'timestamp': reading.timestamp.isoformat(),
            'water_level': reading.water_level,
            'flow_rate': reading.flow_rate,
            'soil_moisture': reading.soil_moisture,
            'water_temperature': reading.water_temperature
        })
    
    return jsonify(data)

@app.route('/api/sensors', methods=['POST'])
def add_sensor_reading():
    """Add a new sensor reading - FROM YOUR ORIGINAL CODE"""
    data = request.get_json()
    
    reading = SensorReading(
        water_level=data['water_level'],
        flow_rate=data['flow_rate'],
        soil_moisture=data['soil_moisture'],
        water_temperature=data['water_temperature']
    )
    
    db.session.add(reading)
    db.session.commit()
    
    # Notify alert service (replaces your check_and_create_alerts function)
    try:
        alert_data = {
            'water_level': reading.water_level,
            'flow_rate': reading.flow_rate,
            'soil_moisture': reading.soil_moisture,
            'water_temperature': reading.water_temperature,
            'timestamp': reading.timestamp.isoformat()
        }
        requests.post(f"{ALERT_SERVICE_URL}/api/check-alerts", 
                     json=alert_data, timeout=5)
    except requests.exceptions.RequestException as e:
        print(f"Failed to notify alert service: {e}")
    
    return jsonify({'message': 'Sensor reading added successfully'}), 201

@app.route('/api/sensors/export')
def export_sensor_data():
    """Export sensor data - FROM YOUR ORIGINAL CODE"""
    sensors = SensorReading.query.order_by(SensorReading.timestamp.desc()).limit(100).all()
    
    export_data = {
        'export_timestamp': datetime.utcnow().isoformat(),
        'sensors': [{
            'timestamp': s.timestamp.isoformat(),
            'water_level': s.water_level,
            'flow_rate': s.flow_rate,
            'soil_moisture': s.soil_moisture,
            'water_temperature': s.water_temperature
        } for s in sensors]
    }
    
    return jsonify(export_data)

def generate_sample_data():
    """Generate sample data for testing - FROM YOUR ORIGINAL CODE"""
    print("Generating sample data...")
    
    # Clear existing data
    db.session.query(SensorReading).delete()
    
    # Generate sensor readings for the last 24 hours
    base_time = datetime.utcnow() - timedelta(hours=24)
    
    for i in range(288):  # Every 5 minutes for 24 hours
        timestamp = base_time + timedelta(minutes=i * 5)
        
        # Generate realistic sensor data with some variation
        water_level = 85 + random.uniform(-15, 10)
        flow_rate = 24.5 + random.uniform(-10, 15)
        soil_moisture = 67 + random.uniform(-20, 25)
        water_temperature = 22.5 + random.uniform(-5, 8)
        
        # Keep values in realistic ranges
        water_level = max(0, min(100, water_level))
        flow_rate = max(0, min(50, flow_rate))
        soil_moisture = max(0, min(100, soil_moisture))
        water_temperature = max(5, min(35, water_temperature))
        
        reading = SensorReading(
            timestamp=timestamp,
            water_level=water_level,
            flow_rate=flow_rate,
            soil_moisture=soil_moisture,
            water_temperature=water_temperature
        )
        db.session.add(reading)
    
    db.session.commit()
    print("Sample data generated successfully!")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Check if we need to generate sample data
        if SensorReading.query.count() == 0:
            generate_sample_data()
    
    port = int(os.getenv('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)