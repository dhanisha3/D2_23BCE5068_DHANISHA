#!/usr/bin/env python3
"""
Alert Management Microservice - Handles alerts only
"""

from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime, timedelta
import random
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///alerts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

CORS(app)
db = SQLAlchemy(app)

# Database Models (from your original app.py)
class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    alert_type = db.Column(db.String(20), nullable=False)  # warning, danger, success
    icon = db.Column(db.String(10), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    message = db.Column(db.String(200), nullable=False)
    is_active = db.Column(db.Boolean, default=True)

# Health check
@app.route('/health')
def health_check():
    return jsonify({'status': 'healthy', 'service': 'alert-service'})

# Your original alert routes
@app.route('/api/alerts')
def get_alerts():
    """Get recent alerts - FROM YOUR ORIGINAL CODE"""
    alerts = Alert.query.filter_by(is_active=True).order_by(
        Alert.timestamp.desc()
    ).limit(10).all()
    
    data = []
    for alert in alerts:
        data.append({
            'id': alert.id,
            'timestamp': alert.timestamp.isoformat(),
            'type': alert.alert_type,
            'icon': alert.icon,
            'title': alert.title,
            'message': alert.message
        })
    
    return jsonify(data)

@app.route('/api/check-alerts', methods=['POST'])
def check_and_create_alerts():
    """Check sensor readings and create alerts - FROM YOUR ORIGINAL CODE"""
    data = request.get_json()
    
    # Extract sensor values
    water_level = data.get('water_level', 0)
    flow_rate = data.get('flow_rate', 0)
    soil_moisture = data.get('soil_moisture', 0)
    water_temperature = data.get('water_temperature', 0)
    
    alerts_created = []
    
    # Your original alert logic
    if water_level > 95:
        alert = create_alert('danger', '🚨', 'Tank Overflow Warning', 'Water level critically high')
        alerts_created.append(alert.id)
    
    if flow_rate > 40:
        alert = create_alert('warning', '⚠️', 'High Flow Rate Detected', 'Possible leak detected')
        alerts_created.append(alert.id)
    
    if soil_moisture < 20:
        alert = create_alert('warning', '🌱', 'Low Soil Moisture', 'Irrigation may be needed')
        alerts_created.append(alert.id)
    
    if water_temperature > 30:
        alert = create_alert('warning', '🌡️', 'High Water Temperature', 'Temperature exceeds optimal range')
        alerts_created.append(alert.id)
    
    if water_temperature < 10:
        alert = create_alert('warning', '❄️', 'Low Water Temperature', 'Risk of freezing detected')
        alerts_created.append(alert.id)
    
    return jsonify({
        'message': f'Alert check completed, {len(alerts_created)} alerts created',
        'alerts_created': alerts_created
    })

def create_alert(alert_type, icon, title, message):
    """Create a new alert - FROM YOUR ORIGINAL CODE"""
    alert = Alert(
        alert_type=alert_type,
        icon=icon,
        title=title,
        message=message
    )
    db.session.add(alert)
    db.session.commit()
    return alert

@app.route('/api/alerts/clear', methods=['POST'])
def clear_alerts():
    """Clear all alerts"""
    Alert.query.update({'is_active': False})
    db.session.commit()
    return jsonify({'message': 'All alerts cleared'})

@app.route('/api/alerts/export')
def export_alerts():
    """Export alerts data - FROM YOUR ORIGINAL CODE"""
    alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(50).all()
    
    export_data = {
        'export_timestamp': datetime.utcnow().isoformat(),
        'alerts': [{
            'timestamp': a.timestamp.isoformat(),
            'type': a.alert_type,
            'title': a.title,
            'message': a.message
        } for a in alerts]
    }
    
    return jsonify(export_data)

def generate_sample_alerts():
    """Generate sample alerts - FROM YOUR ORIGINAL CODE"""
    print("Generating sample alerts...")
    
    # Clear existing alerts
    db.session.query(Alert).delete()
    
    # Generate some sample alerts
    sample_alerts = [
        {'type': 'success', 'icon': '✅', 'title': 'System Online', 'message': 'All systems operational'},
        {'type': 'warning', 'icon': '⚠️', 'title': 'High Water Usage', 'message': 'Usage above normal levels'},
        {'type': 'success', 'icon': '💧', 'title': 'Tank Refilled', 'message': 'Water tank successfully refilled'},
    ]
    
    for alert_data in sample_alerts:
        alert = Alert(
            timestamp=datetime.utcnow() - timedelta(minutes=random.randint(5, 120)),
            alert_type=alert_data['type'],
            icon=alert_data['icon'],
            title=alert_data['title'],
            message=alert_data['message']
        )
        db.session.add(alert)
    
    db.session.commit()
    print("Sample alerts generated successfully!")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Check if we need sample data
        if Alert.query.count() == 0:
            generate_sample_alerts()
    
    port = int(os.getenv('PORT', 5001))
    app.run(debug=True, host='0.0.0.0', port=port)