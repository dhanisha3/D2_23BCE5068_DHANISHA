#!/usr/bin/env python3
"""
Dashboard & Analytics Microservice - Split from your original app.py
Handles web interface, metrics, and system coordination
"""

from flask import Flask, jsonify, render_template, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime, timedelta
import random
import requests
import os

app = Flask(__name__)

# Database configuration
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///dashboard_metrics.db')
app.config['SQLALCHEMY_DATABASE_URI'] = DATABASE_URL
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Service URLs for communication
SENSOR_SERVICE_URL = os.getenv('SENSOR_SERVICE_URL', 'http://localhost:5000')
ALERT_SERVICE_URL = os.getenv('ALERT_SERVICE_URL', 'http://localhost:5001')

CORS(app)
db = SQLAlchemy(app)

# Database Models (from your original app.py)
class SystemMetrics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    cpu_utilization = db.Column(db.Float, nullable=False)
    response_time = db.Column(db.Float, nullable=False)
    throughput = db.Column(db.Float, nullable=False)
    storage_util = db.Column(db.Float, nullable=False)
    energy_consumption = db.Column(db.Float, nullable=False)
    alert_accuracy = db.Column(db.Float, nullable=False)

# Health check
@app.route('/health')
def health_check():
    return jsonify({'status': 'healthy', 'service': 'dashboard-service'})

# Your original main route
@app.route('/')
def index():
    """Main dashboard - FROM YOUR ORIGINAL CODE"""
    return render_template('index.html')

# Your original metrics route
@app.route('/api/metrics/current')
def get_current_metrics():
    """Get the latest system metrics - FROM YOUR ORIGINAL CODE"""
    latest = SystemMetrics.query.order_by(SystemMetrics.timestamp.desc()).first()
    if not latest:
        return jsonify({'error': 'No metrics data available'}), 404
    
    return jsonify({
        'timestamp': latest.timestamp.isoformat(),
        'cpu_utilization': latest.cpu_utilization,
        'response_time': latest.response_time,
        'throughput': latest.throughput,
        'storage_util': latest.storage_util,
        'energy_consumption': latest.energy_consumption,
        'alert_accuracy': latest.alert_accuracy
    })

# Proxy routes to other services (maintains your original API structure)
@app.route('/api/sensors/current')
def get_current_sensors():
    """Proxy to sensor service - maintains your original API"""
    try:
        response = requests.get(f"{SENSOR_SERVICE_URL}/api/sensors/current", timeout=10)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Sensor service unavailable: {str(e)}'}), 503

@app.route('/api/sensors/history')
def get_sensor_history():
    """Proxy to sensor service - maintains your original API"""
    try:
        response = requests.get(f"{SENSOR_SERVICE_URL}/api/sensors/history", timeout=10)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Sensor service unavailable: {str(e)}'}), 503

@app.route('/api/sensors', methods=['POST'])
def add_sensor_reading():
    """Proxy to sensor service - maintains your original API"""
    try:
        data = request.get_json()
        response = requests.post(f"{SENSOR_SERVICE_URL}/api/sensors", 
                               json=data, timeout=10)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Sensor service unavailable: {str(e)}'}), 503

@app.route('/api/alerts')
def get_alerts():
    """Proxy to alert service - maintains your original API"""
    try:
        response = requests.get(f"{ALERT_SERVICE_URL}/api/alerts", timeout=10)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Alert service unavailable: {str(e)}'}), 503

@app.route('/api/export')
def export_data():
    """Export all data from all services - FROM YOUR ORIGINAL CODE"""
    try:
        # Get data from sensor service
        sensor_response = requests.get(f"{SENSOR_SERVICE_URL}/api/sensors/export", timeout=15)
        sensor_data = sensor_response.json() if sensor_response.status_code == 200 else {}
        
        # Get data from alert service
        alert_response = requests.get(f"{ALERT_SERVICE_URL}/api/alerts/export", timeout=15)
        alert_data = alert_response.json() if alert_response.status_code == 200 else {}
        
        # Get metrics data
        metrics = SystemMetrics.query.order_by(SystemMetrics.timestamp.desc()).limit(50).all()
        metrics_data = [{
            'timestamp': m.timestamp.isoformat(),
            'cpu_utilization': m.cpu_utilization,
            'response_time': m.response_time,
            'throughput': m.throughput,
            'storage_util': m.storage_util,
            'energy_consumption': m.energy_consumption,
            'alert_accuracy': m.alert_accuracy
        } for m in metrics]
        
        # Combine all data (same format as your original export)
        export_data = {
            'export_timestamp': datetime.utcnow().isoformat(),
            'sensors': sensor_data.get('sensors', []),
            'alerts': alert_data.get('alerts', []),
            'metrics': metrics_data
        }
        
        return jsonify(export_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Service status endpoint
@app.route('/api/status')
def get_service_status():
    """Check status of all microservices"""
    services = {
        'sensor_service': {'url': SENSOR_SERVICE_URL, 'status': 'unknown'},
        'alert_service': {'url': ALERT_SERVICE_URL, 'status': 'unknown'},
        'dashboard_service': {'url': 'local', 'status': 'healthy'}
    }
    
    # Check sensor service
    try:
        response = requests.get(f"{SENSOR_SERVICE_URL}/health", timeout=5)
        services['sensor_service']['status'] = 'healthy' if response.status_code == 200 else 'unhealthy'
    except:
        services['sensor_service']['status'] = 'unreachable'
    
    # Check alert service
    try:
        response = requests.get(f"{ALERT_SERVICE_URL}/health", timeout=5)
        services['alert_service']['status'] = 'healthy' if response.status_code == 200 else 'unhealthy'
    except:
        services['alert_service']['status'] = 'unreachable'
    
    return jsonify(services)

def generate_sample_metrics():
    """Generate sample metrics - FROM YOUR ORIGINAL CODE"""
    print("Generating sample metrics...")
    
    # Clear existing metrics
    db.session.query(SystemMetrics).delete()
    
    # Generate system metrics for the last 24 hours
    base_time = datetime.utcnow() - timedelta(hours=24)
    
    for i in range(48):  # Every 30 minutes for 24 hours
        timestamp = base_time + timedelta(minutes=i * 30)
        
        metrics = SystemMetrics(
            timestamp=timestamp,
            cpu_utilization=random.uniform(50, 90),
            response_time=random.uniform(150, 350),
            throughput=random.uniform(800, 1500),
            storage_util=random.uniform(30, 70),
            energy_consumption=random.uniform(120, 180),
            alert_accuracy=random.uniform(94, 99)
        )
        db.session.add(metrics)
    
    db.session.commit()
    print("Sample metrics generated successfully!")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Check if we need sample data
        if SystemMetrics.query.count() == 0:
            generate_sample_metrics()
    
    port = int(os.getenv('PORT', 5002))
    app.run(debug=True, host='0.0.0.0', port=port)